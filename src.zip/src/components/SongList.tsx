import React, { useState } from "react";
import { Song } from "../types/song";
import SongItem from "./SongItem";
import style from "./SongList.module.css";

interface Props {
  songs: Song[];
  header: string;
  setSongs: (songs: Song[]) => void;
}

const SongList = ({ songs, header, setSongs }: Props) => {
  return (
    <>
      <h1>{header}</h1>
      <div className={style.SongList}>
        {songs.map((song) => (
          <SongItem
            key={song.id}
            song={song}
            handleRemoveSong={() =>
              setSongs(songs.filter((item) => item !== song))
            }
          />
        ))}
      </div>
    </>
  );
};

export default SongList;
