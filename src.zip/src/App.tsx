import { useState } from "react";
import "./App.css";
import SongForm from "./components/SongForm";
import SongsFilter from "./components/SongsFilter";
import { FakeSongsData } from "./data/FakeData";
import SongList from "./components/SongList";

function App() {
  const [filter, setFilter] = useState("all");
  const [songs, setSongs] = useState(FakeSongsData);

  const filteredSongs =
    filter === "all"
      ? FakeSongsData
      : FakeSongsData.filter((song) => song.status === filter);

  return (
    <div className="AppRoot">
      <SongForm />
      <SongsFilter setFilter={setFilter} />
      <SongList
        songs={filteredSongs}
        header={filter}
        setSongs={(prev) => setSongs(prev)}
      />
    </div>
  );
}

export default App;
